# LAIG 2020/2021 - TP2

## Group T07G09
| Name             | Number    | E-Mail             |
| ---------------- | --------- | ------------------ |
| Luís Assunção    | 201806140 |up201806140@fe.up.pt|
| João Rocha       | 201806261 |up201806261@fe.up.pt|

----
## Project information

- Todo o trabalho foi realizado de acordo com enunciado. A cena contém todos os obejtos de avaliação pedidos (animação por keyframes, sprite animations, sprite text, primitivas plano, patch e barrel constuídas em superfícies NURBS)
- Scene
  - Área de piscina com duas cadeiras, uma delas com uma animação por keyframes e uma propulsão animada com sprite animation, uma bola, uma bóia, duas bandeiras, 4 paredes, uma prancha e um chuveiro, uma espreguiçadeira, uma mesa de apoio à espreguiçadeira e um texto a dizer "LAIG 2020"
  - ./scenes/LAIG_TP2_XML_T7_G09.xml
----
## Issues/Problems

- No know issue

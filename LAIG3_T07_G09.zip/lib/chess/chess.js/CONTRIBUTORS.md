Special thanks to the following developers for their patches and contributions
(alphabetically):

-   [Steve Bragg](https://github.com/2sb18)
-   [Ngoc Dao](https://github.com/ngocdaothanh)
-   [Matt Flaschen](https://github.com/mattflaschen)
-   [E. Azer Koçulu](https://github.com/azer)
-   [Falco Nogatz](https://github.com/fnogatz)
-   [jdponomarev](https://github.com/jdponomarev)
-   [Tom Offermann](https://github.com/toffer)
-   [David Moises Paz Reyes](https://github.com/davidmpaz)
-   [Raminder Singh](https://github.com/imor)
-   [Stiff](https://github.com/stiff)
-   [Seb Vincent](https://github.com/sebv)
-   [Linmiao Xu](https://github.com/linrock)
-   [Jonathan Zacsh](https://github.com/jzacsh)

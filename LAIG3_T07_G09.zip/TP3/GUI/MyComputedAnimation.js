/**
 * MyAnimation class, representing an intermediate node in the scene graph.
 * @method constructor
 * 
 **/
function MyComputedAnimation() {
 
    this.trans_vec = [];
    this.current=0;
    this.cumulative=[0,0,0];
}

